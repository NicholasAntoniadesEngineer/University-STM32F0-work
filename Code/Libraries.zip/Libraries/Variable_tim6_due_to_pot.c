// STDNUM001file:///home/nick/Desktop/Microsforc/Libraries/stm32f0_startup.s

// Prac Exam 1 Part 2 Solution 2015-10-16

#include <stdint.h>
#define STM32F051
#include "stm32f0xx.h"  // you can remove this if you're not using it
#include "libs.h"
// DO NOT CHANGE THIS ARRAY. The marker will change the values *AND LENGTH* at compile time.
int i = 0;
void loop(void);

int main(void) {
        // initialisations here
    libs_init_ADC_8bit();
    libs_init_leds();
    libs_init_switches();
    libs_init_TIM6(2000, 4000);

    loop();

    // suggestion: find and store the largest value and smallest value in the array here.
    // hang in an infinite loop

    return 0;  // keep compiler happy with a return code.

}
void loop(void){
    libs_delay(50);
    int pot0 = libs_read_ADC(0,8); 
    libs_TIM6_PSC((pot0*20)+ 1000);// Gradient between PSC and POT VALUE (not time).
    loop();


}

void TIM6_DAC_IRQHandler(void) {
    libs_ack_irq();

    libs_write_leds(i);
    i =i + 1;
}


