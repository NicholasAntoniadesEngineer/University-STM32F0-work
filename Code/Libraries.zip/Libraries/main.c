// STDNUM001file:///home/nick/Desktop/Microsforc/Libraries/stm32f0_startup.s

// Prac Exam 1 Part 2 Solution 2015-10-16

#include <stdint.h>
#define STM32F051
#include "stm32f0xx.h"  // you can remove this if you're not using it
#include "libs.h"
// DO NOT CHANGE THIS ARRAY. The marker will change the values *AND LENGTH* at compile time.
int i = 0;
void loop(void);

int main(void) {
    // initialisations here
	libs_init_leds();
	libs_init_switches();

    // suggestion: find and store the largest value and smallest value in the array here
	//libs_sort(myArray, sizeof(myArray)/sizeof(myArray[0]));

	//libs_write_leds(myArray[10]);

    // hang in an infinite loop
    while(1) {
		if (libs_check_button(0)) {
			libs_write_leds(1);
		} else if (libs_check_button(1)) {
			libs_write_leds(2);
		} else if (libs_check_button(2)) {
			libs_write_leds(4);
		} else if (libs_check_button(3)) {
			libs_write_leds(8);
		}
        // if SW0 not held, display largest value from array.
        // if SW0 is held, display smallest value from array.
    }
    return 0;  // keep compiler happy with a return code.

}

void TIM6_DAC_IRQHandler(void) {
   /* libs_ack_irq();
    libs_write_leds(i);
    i =i + 1;
    if(i==0x100){
        i = 0;
    }*/

}

